// add user to the DOM function
let addUser = (userId, imgUrl, fullName, phoneNum, address) => {
  let user = document.createElement("div");
  user.classList.add("user");
  user.innerHTML = `<div class="userHeader">
                    <span>${userId}</span
                    ><img
                      src="${imgUrl}"
                    />
                  </div>
                  <div class="userBody">
                    <ul>
                      <li>${fullName.fname} ${fullName.lname}</li>
                      <li>${phoneNum}</li>
                      <li>${address}</li>
                    </ul>
                  </div>`;
  document
    .querySelector("a#loadMore")
    .insertAdjacentElement("beforebegin", user);
};

let LoadDataAndAdd = () => {
  // HTTP request =========>
  let xhr = new XMLHttpRequest();

  xhr.open(
    "GET",
    "http://www.filltext.com/?rows=38&fname={firstName}&lname={lastName}&tel={phone|format}&address={streetAddress}",
    true
  );

  xhr.onload = () => {
    let data = JSON.parse(xhr.responseText);
    data.forEach((elm) => {
      let fullName = {
          fname: elm.fname,
          lname: elm.lname,
        },
        imgUrl =
          "https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png";

      addUser("userId", imgUrl, fullName, elm.tel, elm.address);
    });
  };
  // send the request
  xhr.send();
  // End Http request
};

document.querySelector("a#loadMore").addEventListener("click", LoadDataAndAdd);

// ********************

LoadDataAndAdd();
window.onscroll = () => {
  let scrollable = document.documentElement.scrollHeight - window.innerHeight;

  let scrolled = window.scrollY;

  if (scrolled === scrollable) {
    LoadDataAndAdd();
  }
};
